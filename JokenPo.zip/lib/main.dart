import 'package:flutter/material.dart';
import 'package:jokenpo/jogo.dart';

void main() {
  runApp(MaterialApp(
    home: Jogo(),
  ));
}
